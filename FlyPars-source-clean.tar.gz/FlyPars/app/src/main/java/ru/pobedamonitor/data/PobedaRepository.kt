package ru.pobedamonitor.data

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

/**
 * Парсер цен авиакомпании «Победа» (flypobeda.ru).
 *
 * Использует внутренний API сайта (тот же, что использует страница
 * «Лучшие предложения» на https://www.flypobeda.ru):
 *   GET https://site-api.flypobeda.ru/best-offers/multi
 *       ?locale=ru&departure[0]=MOW|MSQ&dates[0]=YYYY-MM-DD
 *
 * Ответ — массив направлений с минимальной ценой на запрошенную дату.
 */
class PobedaRepository {

    companion object {
        const val API_BASE = "https://site-api.flypobeda.ru/best-offers/multi"
        /**
         * v2.14: реальное РАСПИСАНИЕ рейсов (время вылета по местному часовому
         * поясу аэропорта). Поле flightTime в best-offers — это ДЛИТЕЛЬНОСТЬ
         * перелёта, а не время вылета; вылет берём только отсюда.
         */
        const val TIMETABLE_API = "https://site-api.flypobeda.ru/flight-timetable"
        const val SITE_URL = "https://www.flypobeda.ru"

        /**
         * v2.33: реальный адрес бронирования Победы. Старый `www.flypobeda.ru/mobile/search`
         * больше не существует и отдаёт «404 страница не найдена». Официальная кнопка
         * «Купить билет» на сайте ведёт на `ticket.flypobeda.ru/websky/...#/search`.
         */
        private const val BOOKING_BASE = "https://ticket.flypobeda.ru/websky/search"

        /**
         * v2.34: справочник «IATA рейсов (Победа) → город/аэропорт движка бронирования».
         * Движок websky валидирует параметры по СВОЕМУ словарю `json/dict-cities`.
         * Коды из расписания Победы, которые движок знает ТОЛЬКО как аэропорты
         * внутри города с другим кодом (город → его IATA-код аэропорта):
         */
        private val BOOKING_AIRPORT_TO_CITY = mapOf<String, String>()

        /** Пункт для ссылки покупки: код города + необязательный код аэропорта. */
        data class BookingGeoPoint(val cityCode: String, val portCode: String?)

        /** v2.33: запасной адрес — главная страница сайта (гарантированно живая). */
        private const val SITE_SEARCH_FALLBACK = SITE_URL

        /**
         * v2.34: ссылка открывает РЕЗУЛЬТАТЫ ПОИСКА движка websky с конкретным
         * рейсом, а не пустую форму. Формат параметров скопирован из кода самого
         * движка (app.js → redirect на `./search?...`):
         *   date[0]=ДД.ММ.ГГГГ, origin-city-code[0], origin-port-code[0],
         *   destination-city-code[0], segmentsCount=1|2; для «туда-обратно» —
         *   второй сегмент date[1]/origin[1]/destination[1]. Скобки в именах
         *   параметров URL-энкодятся (%5B %5D).
         * Если передана [retDateIso] — два сегмента (обратно тем же маршрутом),
         * иначе один сегмент («только туда»). Для Москвы подставляется выбранный
         * аэропорт хаба (по умолчанию Внуково).
         * [cityDict]/[portToCity] — словарь движка (`json/dict-cities`); пустой —
         * используем IATA-коды как есть (для большинства направлений Победы они совпадают).
         */
        fun buildSearchUrl(
            hubIata: String,
            arrivalIata: String,
            depDateIso: String,
            retDateIso: String? = null,
            moscowAirport: String = "SVO",
            cityDict: Map<String, String> = emptyMap(),
            portToCity: Map<String, String> = emptyMap(),
            /** v2.36: фактический аэропорт вылета рейса (SVO и т.п.) — важнее выбора пользователя. */
            actualDepPort: String? = null,
            /** v2.36: фактический аэропорт возврата (для плеча «обратно»). */
            actualRetPort: String? = null,
            /** v2.37: фактический аэропорт прибытия обратного плеча в хаб. */
            actualArrPort: String? = null,
        ): String {
            fun ruDate(iso: String): String =
                "${iso.substring(8, 10)}.${iso.substring(5, 7)}.${iso.substring(0, 4)}"
            fun enc(s: String): String = Uri.encode(s)
            fun point(iata: String): BookingGeoPoint {
                BOOKING_AIRPORT_TO_CITY[iata]?.let { return BookingGeoPoint(it, iata) }
                if (cityDict.isNotEmpty()) {
                    if (cityDict.containsKey(iata)) return BookingGeoPoint(iata, null)
                    portToCity[iata]?.let { return BookingGeoPoint(it, iata) }
                }
                return BookingGeoPoint(iata, null)
            }

            // v2.40: хабовый город всегда передаём КОДОМ ГОРОДА (MOW/MSQ) без
            // кода аэропорта. Раньше ссылка жёстко подставляла конкретный порт
            // (SVO/VKO по умолчанию или из расписания) — но расписание Победы
            // отдаёт соседние операционные дни, и на запрошенную дату рейс из
            // этого порта мог НЕ выполняться → сайт писал «рейсы не выполняются /
            // нет мест». Город MOW означает «любой аэропорт Москвы»: движок сам
            // найдёт фактический порт на нужную дату (SVO/VKO/DME/ZIA).
            // v2.41: если фактический аэропорт плеча ИЗВЕСТЕН из расписания
            // ([actualPort] != null) — подставляем его явно (город + порт), но
            // только когда он летит ИМЕННО в хаб [hubIata]: раньше ссылка
            // открывала «Внуково» вместо Шереметьево, т.к. движок websky при
            // голом коде города MOW выбирал первый попавшийся московский аэропорт.
            // При этом неизвестный/чужой код порта (например, транзитный аэропорт
            // стыковочного рейса) в URL не попадает — иначе поиск по выдуманному
            // направлению возвращает «рейсы не выполняются».
            fun legPoint(hub: String, other: String, actualPort: String?): BookingGeoPoint {
                if (actualPort != null && portToCity[actualPort] == hub) return point(actualPort)
                val known = cityDict[other] != null || portToCity[other] != null
                return if (known) point(other) else point(hub)
            }
            val dep = legPoint(hubIata, actualDepPort ?: "", actualDepPort)
            val arr = point(arrivalIata)
            // v2.37: обратно летим в ТОТ же московский аэропорт, откуда вылетали
            // (рейс SVO→HMR обычно возвращается SVO←HMR). Иначе движок искал бы
            // возврат в другой аэропорт и писал «нет рейсов на эту дату».
            // v2.40: как и «туда» — кодом города, чтобы движок сам выбрал порт.
            val retDest = legPoint(hubIata, actualArrPort ?: "", actualArrPort)
            val retDep = legPoint(hubIata, actualRetPort ?: arrivalIata, actualRetPort)
            val seg = StringBuilder()
                // v2.38: количество пассажиров — всегда 1 взрослый. Без этих
                // параметров движок websky подставлял 0 пассажиров и поиск
                // возвращал «нет мест / рейсы не выполняются».
                .append("adultsCount=1&childrenCount=0&infantsCount=0")
                .append("&date%5B0%5D=").append(enc(ruDate(depDateIso)))
                .append("&origin-city-code%5B0%5D=").append(enc(dep.cityCode))
            dep.portCode?.let { seg.append("&origin-port-code%5B0%5D=").append(enc(it)) }
            seg.append("&destination-city-code%5B0%5D=").append(enc(arr.cityCode))
            arr.portCode?.let { seg.append("&destination-port-code%5B0%5D=").append(enc(it)) }
            var count = 1
            if (retDateIso != null) {
                count = 2
                seg.append("&date%5B1%5D=").append(enc(ruDate(retDateIso)))
                    .append("&origin-city-code%5B1%5D=").append(enc(retDep.cityCode))
                retDep.portCode?.let { seg.append("&origin-port-code%5B1%5D=").append(enc(it)) }
                // v2.37: возврат — в фактический аэропорт хаба (обычно тот же,
                // откуда вылетали: SVO→обратно→SVO).
                seg.append("&destination-city-code%5B1%5D=").append(enc(retDest.cityCode))
                retDest.portCode?.let { seg.append("&destination-port-code%5B1%5D=").append(enc(it)) }
            }
            seg.append("&segmentsCount=").append(count)
            return "$BOOKING_BASE?$seg"
        }

        /** v2.33: запасная ссылка — форма поиска на главной странице сайта. */
        fun searchFallbackUrl(): String = SITE_SEARCH_FALLBACK

        /** Аэропорты вылета из Москвы (Минск обслуживается одним аэропортом MSQ). */
        val MOSCOW_AIRPORTS = listOf(
            Airport("VKO", "Внуково"),
            Airport("SVO", "Шереметьево"),
            Airport("DME", "Домодедово"),
            Airport("ZIA", "Жуковский"),
        )

        val HUBS = listOf(
            Hub("MOW", "Москва", MOSCOW_AIRPORTS),
            Hub("MSQ", "Минск", listOf(Airport("MSQ", "Минск (Национальный аэропорт)"))),
        )
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val isoFmt: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    /**
     * v2.34: кэш словаря городов движка бронирования websky
     * (`json/dict-cities`). `cityDict`: код города → название;
     * `portToCity`: код аэропорта → код его города (например VKO→MOW).
     * Заполняется один раз при первом обращении (в фоне); до заполнения
     * [bookingPoint] использует коды как есть.
     */
    @Volatile
    private var cityDict: Map<String, String> = emptyMap()

    @Volatile
    private var portToCity: Map<String, String> = emptyMap()

    /**
     * v2.34: ссылка покупки с учётом загруженного словаря движка бронирования.
     * Если словарь ещё не загружен — строим по IATA-кодам как есть и запускаем
     * загрузку на следующий кадр (после перезагрузки списка ссылки будут точнее).
     */
    fun searchUrl(
        hubIata: String,
        arrivalIata: String,
        depDateIso: String,
        retDateIso: String? = null,
        // v2.38: по умолчанию Шереметьево — Победа базируется в SVO, а не во
        // Внуково; раньше ссылка строилась из VKO и сайт писал
        // «рейсы на эту дату не выполняются / нет мест».
        moscowAirport: String = "SVO",
        actualDepPort: String? = null,
        actualRetPort: String? = null,
        /** v2.39: фактический аэропорт прибытия обратного плеча в хаб. */
        actualArrPort: String? = null,
    ): String {
        if (cityDict.isEmpty()) cityDictNeeded = true
        // v2.41: синхронная подгрузка словаря городов движка websky при первом
        // обращении — иначе portToCity пуст и фактический аэропорт рейса (SVO)
        // не попадает в ссылку; пользователь видел «Внуково» вместо Шереметьево.
        if (cityDict.isEmpty()) runCatching { kotlinx.coroutines.runBlocking { ensureCityDict() } }
        return buildSearchUrl(
            hubIata, arrivalIata, depDateIso, retDateIso, moscowAirport,
            cityDict, portToCity, actualDepPort, actualRetPort, actualArrPort,
        )
    }

    /** v2.34: текущий кэш словаря движка (город → название, аэропорт → город). */
    fun cityDictSnapshot(): Pair<Map<String, String>, Map<String, String>> =
        cityDict to portToCity

    /** v2.34: публичный запуск загрузки словаря (UI вызывает при первом тапе «Купить»). */
    suspend fun preloadCityDict() = ensureCityDict()

    /** v2.34: кнопка «Купить» нажата до загрузки словаря — загрузить при следующем refresh. */
    @Volatile
    var cityDictNeeded: Boolean = false
        private set

    private suspend fun ensureCityDict() = withContext(Dispatchers.IO) {
        if (cityDict.isNotEmpty() && !cityDictNeeded) return@withContext
        try {
            val req = Request.Builder()
                .url("https://ticket.flypobeda.ru/websky/json/dict-cities")
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val body = resp.body?.string() ?: return@use
                val arr = JSONArray(body)
                val cities = HashMap<String, String>(arr.length())
                val ports = HashMap<String, String>()
                for (i in 0 until arr.length()) {
                    val c = arr.optJSONObject(i) ?: continue
                    val cc = c.optString("codeEn")
                    if (cc.isBlank()) continue
                    cities[cc] = c.optString("nameRu").ifBlank { c.optString("nameEn") }
                    val aArr = c.optJSONArray("airports") ?: continue
                    for (j in 0 until aArr.length()) {
                        val a = aArr.optJSONObject(j) ?: continue
                        val pc = a.optString("codeEn")
                        if (pc.isNotBlank() && pc != cc) ports[pc] = cc
                    }
                }
                cityDict = cities
                portToCity = ports
                cityDictNeeded = false
            }
        } catch (_: Exception) {
            // Словарь не загрузился — ссылки будут строиться по IATA-кодам как есть.
        }
    }

    /** Один тариф/предложение на конкретную дату по конкретному направлению. */
    data class PriceEntry(
        val depDate: String,      // ISO yyyy-MM-dd
        val price: Int,           // RUB
        val airline: String?,
        val flightTime: String?,
        /** v2.13: «DP,DP» — стыковочный (несколько плечей), «DP» — прямой. */
        val legsCount: Int = 1,
        /** v2.13: время вылета из ответа API (HH:mm или H:mm). */
        val depTime: String? = null,
        /**
         * v2.16: true — depTime подтверждён официальным расписанием (stdLocal);
         * false — depTime не подтверждён и показывать его НЕЛЬЗЯ, потому что
         * поле flightTime в best-offers — это ДЛИТЕЛЬНОСТЬ перелёта, а не
         * время вылета (например «1:30» для Минск→СПб при вылете в 19:40).
         */
        val depTimeVerified: Boolean = false,
        /**
         * v2.17: номер рейса подтверждённого вылета из расписания (DP6859).
         * Нужен, чтобы сопоставить «лучшую цену» из best-offers с конкретным
         * рейсом в многорейсовом дне (Москва→Казань — 3 рейса в день).
         */
        val flightNo: String? = null,
        /**
         * v2.36: фактический аэропорт вылета из расписания (SVO/DME/VKO/ZIA),
         * когда хаб — «MOW» (Москва объединяет 4 аэропорта). Нужен, чтобы
         * кнопка «Купить» вела на рейс из того аэропорта, откуда он реально
         * летит (чаще Шереметьево), а не из выбранного по умолчанию Внуково.
         */
        val depPortIata: String? = null,
        /**
         * v2.37: фактический аэропорт ПРИБЫТИЯ этого плеча из расписания.
         * Для обратного плеча (город→Москва) позволяет построить возврат
         * в тот же московский аэропорт, что и вылет («туда SVO → обратно SVO»).
         */
        val arrPortIata: String? = null,
    ) {
        /** Прямой рейс (одно плечо) или стыковочный (через другой город). */
        val isDirect: Boolean get() = legsCount <= 1

        /**
         * v2.13: подпись формата «09 окт · 14:55 · прямой» / «… · стыковочный».
         * [dateFmt] — формат даты (например, d MMM); без времени возвращает только дату.
         */
        fun flightLabel(dateFmt: DateTimeFormatter): String {
            val sb = StringBuilder()
            runCatching { LocalDate.parse(depDate).format(dateFmt) }
                .onSuccess { sb.append(it) }
                .onFailure { sb.append(depDate) }
            // v2.16: время показываем ТОЛЬКО подтверждённое расписанием — иначе
            // это длительность полёта из best-offers, а не вылет.
            if (depTimeVerified) depTime?.let { sb.append(" · ").append(normalizeTime(it)) }
            // v2.17: номер рейса — чтобы можно было сверить с сайтом Победы.
            flightNo?.let { sb.append(" · ").append(it) }
            sb.append(if (isDirect) " · прямой" else " · стыковочный")
            return sb.toString()
        }

        companion object {
            /** Приводит «1:30»/«24:00» к виду «01:30»; значения не-времени скрывает. */
            fun normalizeTime(raw: String?): String? {
                if (raw.isNullOrBlank()) return null
                val parts = raw.trim().split(":")
                if (parts.size != 2) return null
                val h = parts[0].toIntOrNull() ?: return null
                val m = parts[1].toIntOrNull() ?: return null
                if (m !in 0..59) return null
                return "%02d:%02d".format(h % 24, m)
            }
        }
    }

    /** Направление + цены по всем запрошенным датам. */
    data class RoutePrices(
        val hubIata: String,
        val arrivalIata: String,
        val arrivalName: String,
        val prices: Map<String, PriceEntry>,   // date -> entry
    ) {
        val cheapest: PriceEntry? get() = prices.values.minByOrNull { it.price }

        /**
         * v2.14: лучшая цена среди дат, удовлетворяющих предикату [keepDate]
         * (например, только выбранные дни недели режима «выходных»).
         */
        fun cheapestFiltered(keepDate: (LocalDate) -> Boolean): PriceEntry? =
            prices.values.filter { e ->
                runCatching { keepDate(LocalDate.parse(e.depDate)) }.getOrDefault(false)
            }.minByOrNull { it.price }
    }

    data class FetchResult(
        val routes: List<RoutePrices>,
        val errors: List<String>,
    )

    /**
     * Загружает цены по всем направлениям из указанных хабов (по умолчанию —
     * Москва MOW и Минск MSQ) на диапазон дат [from]..[to] включительно.
     */
    suspend fun fetchPrices(
        from: LocalDate,
        to: LocalDate,
        hubs: List<String> = HUBS.map { it.iata },
        onlyDates: Set<LocalDate>? = null,
        enrich: Boolean = true,
    ): FetchResult = withContext(Dispatchers.IO) {
        // В режиме «выходных» запрашиваем только выбранные даты (например, пятницы),
        // в обычном — все дни диапазона подряд.
        val dates = if (!onlyDates.isNullOrEmpty()) {
            onlyDates.sorted()
        } else {
            generateSequence(from) { if (it < to) it.plusDays(1) else null }.toList()
        }
        val errors = java.util.concurrent.ConcurrentLinkedQueue<String>()

        // v2.45: СКОРОСТЬ. Основной запрос цен — пакетный: вместо N последовательных
        // HTTP-вызовов (по одному на дату) API best-offers/multi поддерживает
        // несколько параметров dates[N], поэтому весь диапазон берётся одним
        // запросом на хаб (чанки по 15 дат). Именно так загрузка была быстрой
        // до появления сверки цены/рейса в v2.43.
        val routes: List<RoutePrices> = coroutineScope {
            hubs.map { hub ->
                async {
                    // Один запрос на чанк дат (API поддерживает dates[N]) — это
                    // в ~15 раз меньше сетевых обращений, чем по-датный обход.
                    val dayResults = ArrayList<RoutePrices>(dates.size)
                    dates.chunked(15).forEach { chunk ->
                        try {
                            val j = fetchDirectionJson(hub, chunk)
                            val keep = chunk.map { it.format(isoFmt) }.toSet()
                            dayResults.addAll(parseDayFiltered(hub, j, keep))
                        } catch (e: Exception) {
                            errors.add("$hub ${chunk.first()}..${chunk.last()}: ${e.message ?: e.javaClass.simpleName}")
                        }
                    }
                    dayResults
                }
            }.awaitAll().flatten()
        }

        // v2.45: параллельно с ценами грузим ответы best-offers по московским
        // портам (для сверки цены и рейса в matchMoscowPortByPrice) — теперь
        // ЭТО НЕ БЛОКИРУЕТ выдачу результатов: запрос уходит в фоновую корутину,
        // а enrichment дождётся его только когда действительно нужен.
        // v2.46: предзагрузка портов Москвы УДАЛЕНА из основного пути загрузки.
        // Она добавляла ~4 пакетных запроса к каждому refresh'у и заметно
        // замедляла выдачу результатов (жалоба: «версия без показа времени
        // работала куда быстрее»). Ссылка «Купить» по-прежнему корректна:
        // enrichment подтягивает данные порта только для выбранной даты
        // (один быстрый запрос в matchMoscowPortByPrice), а не для всего
        // диапазона заранее.

        // v2.46: но фоновая предзагрузка ВСЁ ЖЕ нужна — иначе сверка цены и
        // рейса (matchMoscowPortByPrice) при открытии карточки делает до 4
        // разовых сетевых запросов на дату и ссылка «Купить» строится дольше.
        // Запускаем её ПОСЛЕ формирования merged-списка, отдельной корутиной:
        // она не участвует в awaitAll основного запроса и не задерживает
        // выдачу результатов — просто наполняет moscowPortPriceCache в фоне.
        if (hubs.any { it == "MOW" }) {
            moscowPrefetchJob = kotlinx.coroutines.CoroutineScope(
                coroutineContext + Dispatchers.IO +
                    kotlinx.coroutines.SupervisorJob()
            ).launch {
                runCatching {
                    coroutineScope {
                        MOSCOW_AIRPORTS.map { ap ->
                            async {
                                dates.chunked(15).forEach { chunk ->
                                    try {
                                        val j = fetchDirectionJson(ap.iata, chunk)
                                        for (i in 0 until j.length()) {
                                            val o = j.optJSONObject(i) ?: continue
                                            val d = o.optJSONObject("minOffer")
                                                ?.optString("depDate").orEmpty()
                                            if (d.isNotBlank()) {
                                                moscowPortPriceCache.putIfAbsent(
                                                    "${ap.iata}|$d", j
                                                )
                                            }
                                        }
                                    } catch (_: Exception) {
                                    }
                                }
                            }
                        }.awaitAll()
                    }
                }
            }
        }

        // склеиваем одинаковые направления в одну запись со словарём дат
        val merged = routes
            .groupBy { it.hubIata to it.arrivalIata }
            .values
            .map { parts ->
                RoutePrices(
                    hubIata = parts.first().hubIata,
                    arrivalIata = parts.first().arrivalIata,
                    arrivalName = parts.first().arrivalName,
                    prices = parts.flatMap { p -> p.prices.values }
                        .filter { e ->
                            // В режиме «выходных» API может вернуть соседние даты —
                            // оставляем только запрошенные.
                            onlyDates.isNullOrEmpty() ||
                                runCatching { LocalDate.parse(e.depDate) in onlyDates }.isSuccess
                        }
                        .associateBy { it.depDate },
                )
            }

        // v2.16: обогащаем ВСЕ записи расписанием ДО сортировки — иначе у
        // неотсортированных элементов теряется depTime (было видно длительность).
        // v2.46: здесь НЕ обогащаем — список цен отдаётся наружу сразу после
        // пакетного запроса; время вылёта и сверка порта подставляются фоном
        // в ViewModel (enrichWithDepartureTimes), как в быстрых версиях до v2.43.
        val enriched = merged

        val sorted = enriched.sortedWith(
            compareBy<RoutePrices> { if (it.hubIata == "MOW") 0 else 1 }
                .thenBy { it.cheapest?.price ?: Int.MAX_VALUE }
        )

        FetchResult(sorted, errors.toList())
    }

    /**
     * Обратные цены для одного направления arrival -> hub на список дат [dates].
     * Если передан непустой [onlyDays], в результат попадают только даты,
     * дни недели которых выбраны (v2.14: уведомления учитывают дни «обратно»).
     */
    suspend fun fetchReturnPrices(
        hubIata: String,
        arrivalIata: String,
        dates: List<LocalDate>,
        onlyDays: Set<java.time.DayOfWeek> = emptySet(),
    ): Map<String, PriceEntry> = withContext(Dispatchers.IO) {
        // v2.48: СКОРОСТЬ + ПОЛНОТА. Раньше обратные цены грузились по одному
        // HTTP-запросу на КАЖДУЮ дату (dates.map{async{httpGetJson}}), а ответ
        // best-offers отдавал лишь ОДНУ запись minOffer — из-за этого часть дат
        // просто не приходила («показывает только лучшие предложения»). Теперь
        // один пакетный запрос чанками по 15 дат (dates[N]) возвращает minOffer
        // на каждую запрошенную дату — как в основном запросе цен туда.
        val entries = coroutineScope {
            dates.chunked(15).map { chunk ->
                async {
                    try {
                        val json = fetchDirectionJson(arrivalIata, chunk)
                        val keep = chunk.map { it.format(isoFmt) }.toSet()
                        parseDayFiltered(hubIata, json, keep)
                            .filter { it.arrivalIata == hubIata }
                            .flatMap { p -> p.prices.values }
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
                .distinctBy { it.depDate }
                .filter { e ->
                    onlyDays.isEmpty() || runCatching {
                        LocalDate.parse(e.depDate).dayOfWeek in onlyDays
                    }.getOrDefault(false)
                }
        }
        // v2.16: время вылета обратно — только из расписания (stdLocal),
        // с поправкой на разницу часовых поясов аэропортов.
        val enriched = enrichEntriesWithTimetable(entries, arrivalIata, hubIata)
        enriched.associateBy { it.depDate }
    }

    private fun buildUrl(hub: String, date: LocalDate): String =
        "$API_BASE?locale=ru&departure%5B0%5D=$hub&dates%5B0%5D=${date.format(isoFmt)}"

    /**
     * v2.41: проверяет, есть ли РЕЙС из конкретного московского аэропорта
     * [portIata] в город [to] на ТОЧНУЮ дату [dateIso]. Возвращает true — если
     * подтверждён, false — если нет (или расписание недоступно). Используется
     * перед открытием ссылки «Купить», чтобы не подставлять аэропорт, из которого
     * на эту дату рейсов нет (иначе сайт пишет «рейсы не выполняются»).
     * v2.41: раньше метод дополнительно дёргал API с onlyOnDate=dateIso и при
     * пустом ответе считал рейс «несуществующим» — но расписание Победы часто
     * «приписывает» ночные/ранние вылеты к соседнему операционному дню, поэтому
     * реальный рейс SVO отбрасывался и ссылка строилась по дефолтному Внуково
     * («выбирает всегда Внуково»). Теперь достаточно подтверждения из
     * закешированной таблицы плеча port->to на эту дату (fetchTimetableDepartureTimes
     * сам учитывает ±2 соседних дня с фильтром по дате вылета).
     */
    suspend fun hasFlightFromMoscowAirport(
        portIata: String,
        to: String,
        dateIso: String,
    ): Boolean = withContext(Dispatchers.IO) {
        val table = runCatching { fetchTimetableDepartureTimes(dateIso) }.getOrDefault(emptyMap())
        if (table.isEmpty()) return@withContext false
        val legs = table["${portIata}-$to"] ?: return@withContext false
        legs.isNotEmpty()
    }

    /**
     * v2.43: СВЕРКА ЦЕНЫ И РЕЙСА. В дне может быть несколько рейсов направления
     * из Москвы (SVO 07:10 и VKO 15:30) с РАЗНЫМИ ценами; best-offers отдаёт на
     * дату только минимальную цену без привязки к аэропорту, поэтому раньше
     * показывался самый ранний рейс (07:10), а цена 1499 относилась к другому.
     * Этот метод запрашивает best-offers по КАЖДОМУ московскому аэропорту
     * отдельно (departure[0]=SVO/VKO/DME/ZIA) на конкретную дату и возвращает
     * аэропорт, чья минимальная цена равна [price] (при совпадении нескольких —
     * самый ранний вылет). null — если совпадений нет или сеть недоступна.
     */
    suspend fun matchMoscowPortByPrice(
        arrivalIata: String,
        dateIso: String,
        price: Int,
    ): String? = matchMoscowPortByPrice(arrivalIata, dateIso, price, null)

    /** v2.47: снимок прогретого кэша best-offers по московским портам для даты. */
    private fun preFetchedFromCache(dateIso: String): Map<String, JSONArray>? {
        val m = HashMap<String, JSONArray>()
        for (ap in MOSCOW_AIRPORTS) {
            moscowPortPriceCache["${ap.iata}|$dateIso"]?.let { m[ap.iata] = it }
        }
        return if (m.isEmpty()) null else m
    }

    /** v2.47: есть ли уже хоть одна таблица расписания в кэше (повторный вход). */
    fun hasEnrichmentCache(): Boolean = timetableCache.isNotEmpty()

    /** v2.47: чтение расписания ТОЛЬКО из кэша, без сетевых запросов. */
    private fun timetableCachePeek(
        dateIso: String,
    ): Map<String, List<Pair<Triple<String?, String, String?>, String>>>? =
        timetableCache[dateIso]

    /**
     * v2.47: прогрев кэшей расписания и цен московских портов БЕЗ изменения
     * списка направлений — вызывается фоном из ViewModel перед «мягким»
     * повтором enrichWithDepartureTimes, чтобы второй проход отработал
     * мгновенно целиком из кэшей.
     */
    suspend fun warmUpEnrichmentCaches(datesIso: List<String>) {
        val dates = datesIso.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (dates.isEmpty()) return
        coroutineScope {
            dates.map { d -> async(Dispatchers.IO) { runCatching { fetchTimetableDepartureTimes(d.format(isoFmt)) } } }
                .awaitAll()
        }
        // предзагрузка best-offers по 4 московским портам (чанки по 15 дат)
        coroutineScope {
            MOSCOW_AIRPORTS.map { ap ->
                async(Dispatchers.IO) {
                    dates.chunked(15).forEach { chunk ->
                        runCatching {
                            val j = fetchDirectionJson(ap.iata, chunk)
                            for (i in 0 until j.length()) {
                                val o = j.optJSONObject(i) ?: continue
                                val d = o.optJSONObject("minOffer")
                                    ?.optString("depDate").orEmpty()
                                if (d.isNotBlank()) {
                                    moscowPortPriceCache.putIfAbsent("${ap.iata}|$d", j)
                                }
                            }
                        }
                    }
                }
            }.awaitAll()
        }
    }

    /**
     * v2.44: кэш ответов best-offers по московским портам: "PORT|yyyy-MM-dd" ->
     * массив направлений за этот день. Заполняется в fetchPrices одним пакетом
     * запросов (по 15 дат на запрос), поэтому сверка цены и рейса работает без
     * повторных сетевых обращений — загрузка результатов снова быстрая, как
     * до v2.43.
     */
    val moscowPortPriceCache =
        java.util.concurrent.ConcurrentHashMap<String, JSONArray>()

    /**
     * v2.45: фоновая задача предзагрузки ответов best-offers по московским портам
     * (см. fetchPrices). enrichWithDepartureTimes ждёт её завершения только в
     * том случае, если кэш ещё пуст — иначе сверка цены и рейса работает
     * мгновенно по кэшу и не тормозит выдачу результатов.
     */
    @Volatile
    var moscowPrefetchJob: kotlinx.coroutines.Job? = null

    /**
     * v2.44: [preFetched] — уже полученные ответы best-offers по московским
     * портам (см. fetchPrices): тогда сверка цены и рейса НЕ делает заново
     * 4 сетевых запроса на каждую дату и не замедляет загрузку результатов.
     */
    suspend fun matchMoscowPortByPrice(
        arrivalIata: String,
        dateIso: String,
        price: Int,
        preFetched: Map<String, JSONArray>?,
    ): String? = withContext(Dispatchers.IO) {
        if (price <= 0 || arrivalIata.isBlank()) return@withContext null
        // v2.47: НЕ ждём фоновую предзагрузку — сверка работает по прогретому
        // кэшу (см. warmUpEnrichmentCaches); нет данных в кэше — разовый
        // запрос ниже. Ожидание job'а раньше блокировало каждую дату на 1.5с.
        data class Cand(val port: String, val minPrice: Int, val earliestTime: String?)
        val cands = MOSCOW_AIRPORTS.mapNotNull { ap ->
            try {
                val json = preFetched?.get(ap.iata)
                    ?: moscowPortPriceCache["${ap.iata}|$dateIso"]
                    ?: httpGetJson(
                        "$API_BASE?locale=ru&departure%5B0%5D=${ap.iata}" +
                            "&dates%5B0%5D=$dateIso"
                    )
                var minP = -1
                for (i in 0 until json.length()) {
                    val obj = json.optJSONObject(i) ?: continue
                    val arr = obj.optJSONObject("arrival") ?: continue
                    if (arr.optString("iataCode") != arrivalIata) continue
                    val od = obj.optJSONObject("minOffer")?.optString("depDate").orEmpty()
                    if (od.isNotBlank() && od != dateIso) continue
                    val offer = obj.optJSONObject("minOffer") ?: continue
                    val p = offer.optInt("price", -1)
                    if (p > 0 && (minP < 0 || p < minP)) minP = p
                }
                if (minP < 0) return@mapNotNull null
                // Самый ранний подтверждённый вылет из этого порта на эту дату.
                val legs = fetchTimetableDepartureTimes(dateIso)["${ap.iata}-$arrivalIata"]
                Cand(ap.iata, minP, legs?.minByOrNull { it.first.second }?.first?.second)
            } catch (_: Exception) {
                null
            }
        }
        if (cands.isEmpty()) return@withContext null
        val exact = cands.filter { it.minPrice == price }
        val chosen = if (exact.isNotEmpty()) {
            exact.sortedBy { it.earliestTime ?: "99:99" }.first()
        } else {
            // Точного совпадения нет (цена могла измениться между запросами) —
            // берём порт с ценой, ближайшей к показанной.
            cands.minByOrNull { kotlin.math.abs(it.minPrice - price) } ?: return@withContext null
        }
        // Считаем совпадением только близкие цены (±5%) — иначе не вмешиваемся.
        if (chosen.minPrice in (price * 0.95f).toInt()..(price * 1.05f).ceilToInt()) {
            chosen.port
        } else null
    }

    private fun Float.ceilToInt(): Int = kotlin.math.ceil(this.toDouble()).toInt()

    /**
     * v2.41: синхронная версия проверки порта — работает только по уже
     * закешированной таблице расписания (без сетевых запросов). Используется
     * в нотификаторе, где вызов происходит вне coroutine-контекста.
     */
    fun hasFlightFromMoscowAirportCached(
        portIata: String,
        to: String,
        dateIso: String,
    ): Boolean {
        val table = timetableCache[dateIso] ?: return true // нет кэша — не мешаем движку
        val legs = table["${portIata}-$to"] ?: return false
        return legs.isNotEmpty()
    }

    /**
     * Запрашивает все направления из [departureIata] на список дат [dates] одним
     * запросом (API поддерживает несколько параметров dates[N]). Используется для
     * обратных билетов: ответ содержит minOffer на каждую запрошенную дату.
     */
    suspend fun fetchDirectionJson(departureIata: String, dates: List<LocalDate>): JSONArray =
        withContext(Dispatchers.IO) {
            val sb = StringBuilder(API_BASE)
                .append("?locale=ru&departure%5B0%5D=").append(departureIata)
            dates.forEachIndexed { idx, d ->
                sb.append("&dates%5B").append(idx).append("%5D=").append(d.format(isoFmt))
            }
            httpGetJson(sb.toString())
        }

    private fun httpGetJson(url: String): JSONArray {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            .header("Accept", "application/json")
            .header("Referer", SITE_URL)
            .build()
        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            val body = resp.body?.string() ?: error("empty body")
            return JSONArray(body)
        }
    }

    private fun httpGetObject(url: String): JSONObject {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            .header("Accept", "application/json")
            .header("Referer", SITE_URL)
            .build()
        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            val body = resp.body?.string() ?: error("empty body")
            return JSONObject(body)
        }
    }

    // ---- v2.14: расписание рейсов (реальное время вылета) -------------------

    /**
     * Кэш расписания: дата ISO -> ("откудаIATA-кудаIATA" -> список рейсов
     * (номер, HH:mm местного вылета), отсортированный по времени).
     * v2.17: в дне может быть НЕСКОЛЬКО рейсов по одной паре аэропортов
     * (Москва→Казань — 3 рейса), поэтому храним все, а не последний.
     */
    private val timetableCache =
        java.util.concurrent.ConcurrentHashMap<String, Map<String, List<Pair<Triple<String?, String, String?>, String>>>>()

    /**
     * Кэш часовых поясов аэропортов IATA->UTC offset (минуты), извлечённый из
     * ответа flight-timetable (std vs stdLocal). Нужен для пересчёта времени
     * вылёта «обратно» в местное время города возврата.
     */
    private val airportUtcOffsetMin = java.util.concurrent.ConcurrentHashMap<String, Int>()

    /** Кэш «не удалось получить расписание на дату» — не долбить API при каждой загрузке. */
    private val timetableMisses = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /**
     * v2.45: запросы расписания «в полёте» — одна сетевая загрузка на дату,
     * параллельные обращения к той же дате ждут её результат (CompletableDeferred).
     */
    private val timetableInflight = HashMap<
        String,
        kotlinx.coroutines.CompletableDeferred<Map<String, List<Pair<Triple<String?, String, String?>, String>>>>,
    >()

    /**
     * Возвращает карту «$from-$to» -> время вылета (HH:mm, местное время аэропорта)
     * на дату [dateIso] из официального расписания flypobeda.ru. Пустая карта —
     * если расписание на дату недоступно (например, дата дальше ~3 дней).
     * v2.14: при пустом ответе пробуем соседние даты (API иногда сдвигает окно ±1 день),
     * но берём только рейсы на запрошенную [dateIso].
     */
    /**
     * v2.36: меняет порядок кандидатов на «самый ранний» только если он летит
     * из того же аэропорта, что и подтверждённый расписанием рейс [flightNo]
     * (или номер неизвестен) — иначе ссылка «Купить» вела бы не на тот рейс,
     * чья цена показана в карточке.
     */
    private fun pickLeg(
        legs: List<Pair<Triple<String?, String, String?>, String>>,
        flightNo: String?,
    ): Pair<Triple<String?, String, String?>, String>? {
        val best = legs.minByOrNull { it.first.second } ?: return null
        if (flightNo == null) return best
        val sameFlight = legs.firstOrNull { it.first.first == flightNo } ?: return best
        return if (sameFlight.first.third == best.first.third) best else sameFlight
    }

    suspend fun fetchTimetableDepartureTimes(dateIso: String): Map<String, List<Pair<Triple<String?, String, String?>, String>>> =
        withContext(Dispatchers.IO) {
            // v2.45: если таблица на дату уже в кэше — мгновенный возврат без сети.
            timetableCache[dateIso]?.let { return@withContext it }
            // Один сетевой запрос на дату одновременно; остальные ждут его ответ.
            val (deferred, isOwner) = synchronized(timetableInflight) {
                val existing = timetableInflight[dateIso]
                if (existing != null) {
                    existing to false
                } else {
                    val d = CompletableDeferred<Map<String, List<Pair<Triple<String?, String, String?>, String>>>>()
                    timetableInflight[dateIso] = d
                    d to true
                }
            }
            if (isOwner) {
                try {
                    loadTimetableUncached(dateIso).also { deferred.complete(it) }
                } catch (e: Exception) {
                    val empty = emptyMap<String, List<Pair<Triple<String?, String, String?>, String>>>()
                    deferred.complete(empty)
                    empty
                } finally {
                    synchronized(timetableInflight) { timetableInflight.remove(dateIso) }
                }
            } else {
                // Запрос по этой дате уже ведёт другая корутина — ждём её ответ.
                deferred.await()
            }
        }

    private fun loadTimetableUncached(dateIso: String): Map<String, List<Pair<Triple<String?, String, String?>, String>>> =
        timetableCache.getOrPut(dateIso) {
                // Дата вне окна расписания? Повторим попытку не раньше чем через 6 часов.
                val missedAt = timetableMisses[dateIso] ?: 0L
                if (System.currentTimeMillis() - missedAt < 6L * 60 * 60 * 1000) return@getOrPut emptyMap()
                val map = runCatching {
                    val json = httpGetObject("$TIMETABLE_API?locale=ru&date=$dateIso")
                    parseTimetableFlights(json, onlyOnDate = null)
                }.getOrDefault(emptyMap())
                val finalMap = if (map.isNotEmpty()) map else {
                    // Соседние даты запроса + фильтр по нужной дате вылета.
                    // v2.37: расписание Победы отдаёт рейсы, «приписанные» к
                    // соседнему операционному дню (ночные вылеты 00:20 и т.п.),
                    // поэтому пробуем 4 соседних дня, а не 2 — иначе день
                    // считался «без рейсов», и ссылка «Купить» строилась по
                    // дефолтному Внуково → движок писал «нет рейсов на дату».
                    val d = runCatching { LocalDate.parse(dateIso, isoFmt) }.getOrNull()
                    var acc: Map<String, List<Pair<Triple<String?, String, String?>, String>>> = emptyMap()
                    if (d != null) {
                        for (nd in listOf(
                            d.plusDays(1), d.minusDays(1), d.plusDays(2), d.minusDays(2),
                        )) {
                            val m = runCatching {
                                val j = httpGetObject("$TIMETABLE_API?locale=ru&date=${nd.format(isoFmt)}")
                                parseTimetableFlights(j, onlyOnDate = dateIso)
                            }.getOrDefault(emptyMap())
                            if (m.isNotEmpty()) { acc = m; break }
                        }
                    }
                    acc
                }
                if (finalMap.isEmpty()) timetableMisses[dateIso] = System.currentTimeMillis()
                finalMap
            }

    /**
     * v2.43: публичный доступ к таблице расписания на дату (для блока
     * «Рейсы в этот день» в UI). Ключ "FROM-TO", значение — список плечей
     * (номер рейса, время вылета HH:mm, аэропорт прибытия).
     */
    suspend fun timetableForDate(dateIso: String): Map<String, List<Pair<Triple<String?, String, String?>, String>>> =
        fetchTimetableDepartureTimes(dateIso)

    /**
     * v2.43: СВЕРКА ЦЕНЫ И РЕЙСА — минимальная цена best-offers Победы для
     * КОНКРЕТНОГО плеча: из порта [portIata] (или любого московского, если
     * передан хаб MOW) в [arrivalIata] на дату [dateIso], с фильтрацией по
     * времени вылета [depTime] ("HH:mm", допуск ±90 минут — расписание и
     * best-offers могут расходиться на стыковках). null — совпадений нет.
     */
    suspend fun priceForFlightLeg(
        hubIata: String,
        arrivalIata: String,
        dateIso: String,
        portIata: String?,
        depTime: String?,
    ): Int? = withContext(Dispatchers.IO) {
        val ports = when {
            portIata != null && portIata != "MOW" -> listOf(portIata)
            hubIata == "MOW" -> MOSCOW_AIRPORTS.map { it.iata }
            else -> listOf(hubIata)
        }
        var best = -1
        for (p in ports) {
            val json = runCatching {
                httpGetJson("$API_BASE?locale=ru&departure%5B0%5D=$p&dates%5B0%5D=$dateIso")
            }.getOrNull() ?: continue
            for (i in 0 until json.length()) {
                val obj = json.optJSONObject(i) ?: continue
                val arr = obj.optJSONObject("arrival") ?: continue
                if (arr.optString("iataCode") != arrivalIata) continue
                val offer = obj.optJSONObject("minOffer") ?: continue
                val ft = offer.optString("flightTime").takeIf { it.isNotBlank() }
                if (depTime != null && ft != null && !timesClose(ft, depTime)) continue
                val pr = offer.optInt("price", -1)
                if (pr > 0 && (best < 0 || pr < best)) best = pr
            }
        }
        if (best > 0) best else null
    }

    /** v2.43: близость двух времён "HH:mm" в пределах 90 минут (с суточным переносом). */
    private fun timesClose(a: String, b: String): Boolean {
        fun mins(s: String): Int? {
            val parts = s.split(":")
            if (parts.size < 2) return null
            val h = parts[0].trim().toIntOrNull() ?: return null
            val m = parts[1].take(2).trim().toIntOrNull() ?: return null
            return h * 60 + m
        }
        val ma = mins(a) ?: return true // без времени в оффере — не фильтруем
        val mb = mins(b) ?: return true
        val d = kotlin.math.abs(ma - mb)
        return d <= 90 || 1440 - d <= 90
    }

    /**
     * v2.16: время ВЫЛЕТА (местное, HH:mm) конкретного плеча from->to на дату
     * dateIso из расписания. v2.17: если в дне несколько рейсов — берём САМЫЙ
     * РАННИЙ подтверждённый (стабильно и правдоподобно для тарифа «без багажа»).
     * v2.37: третьим элементом возвращает фактический аэропорт ПРИБЫТИЯ плеча.
     */
    private suspend fun fetchTimetableDepartureTimeForLeg(
        from: String,
        to: String,
        dateIso: String,
    ): Triple<String?, String?, String>? {
        val table = fetchTimetableDepartureTimes(dateIso)
        if (table.isEmpty()) return null
        val legs = table["$from-$to"]
            ?: MOSCOW_AIRPORTS.firstNotNullOfOrNull { table["${it.iata}-$to"] }
            ?: return null
        val best = legs.minByOrNull { it.first.second } ?: return null
        // (время, номер рейса, аэропорт прибытия)
        return Triple(best.first.second, best.first.first, best.second)
    }

    /**
     * v2.16: подставляет в список тарифов реальное время ВЫЛЕТА из официального
     * расписания для плеча [from]->[to]. Время из stdLocal пересчитывается из
     * местного пояса аэропорта отправления в местный пояс этого же аэропорта —
     * т.е. как есть (вылет показываем по местному времени города вылета).
     * v2.37: дополнительно запоминаем фактические аэропорты вылета/прибытия плеча,
     * чтобы ссылка «Купить» строилась по реальному рейсу (SVO→обратно→SVO),
     * а не по дефолтному Внуково. Для хаба MOW вместо кода московского аэропорта
     * (который может быть стыковочным транзитом) подставляем сам хаб-город.
     */
    private suspend fun enrichEntriesWithTimetable(
        entries: List<PriceEntry>,
        from: String,
        to: String,
    ): List<PriceEntry> {
        if (entries.isEmpty()) return entries
        return entries.map { e ->
            val t = runCatching {
                fetchTimetableDepartureTimeForLeg(from, to, e.depDate)
            }.getOrNull()
            if (t != null) e.copy(
                depTime = t.first,
                depTimeVerified = true,
                flightNo = t.second,
                depPortIata = if (from == "MOW" || from == "MSQ") null else from,
                arrPortIata = when {
                    to == "MOW" -> e.arrPortIata ?: "MOW"   // прилёт в Москву: уточним ниже
                    to == "MSQ" -> "MSQ"
                    else -> to
                },
            ) else e
        }
    }

    /**
     * Разбор ответа flight-timetable; [onlyOnDate] (ISO) — брать только рейсы
     * этого дня вылета. v2.17: храним ВСЕ рейсы пары за день (пара аэропортов
     * может иметь 2–4 рейса: Москва→Казань DP6843 06:55, DP6841 08:00,
     * DP6859 15:55 — старая реализация оставляла последний попавшийся).
     * v2.36: третий элемент Triple — фактический аэропорт вылета (IATA).
     * v2.37: четвёртый элемент (String) — фактический аэропорт прибытия (to),
     * нужен для возврата «в тот же аэропорт Москвы, откуда вылетали».
     */
    private fun parseTimetableFlights(
        json: org.json.JSONObject,
        onlyOnDate: String?,
    ): Map<String, List<Pair<Triple<String?, String, String?>, String>>> {
        val flights = json.optJSONArray("flights") ?: return emptyMap()
        val map = HashMap<String, MutableList<Pair<Triple<String?, String, String?>, String>>>()
        for (i in 0 until flights.length()) {
            val f = flights.optJSONObject(i) ?: continue
            val dep = f.optJSONObject("departure") ?: continue
            val arr = f.optJSONObject("arrival") ?: continue
            val from = dep.optString("iata").takeIf { it.isNotBlank() } ?: continue
            val to = arr.optString("iata").takeIf { it.isNotBlank() } ?: continue
            // stdLocal — время вылета по МЕСТНОМУ часовому поясу аэропорта.
            val stdLocal = dep.optString("stdLocal").takeIf { it.isNotBlank() && !it.startsWith("01.01.1900") }
            val std = dep.optString("std").takeIf { it.isNotBlank() && !it.startsWith("01.01.1900") }
            // Запоминаем UTC offset аэропорта вылета (stdLocal - std).
            if (stdLocal != null && std != null) {
                val off = utcOffsetMinutes(std, stdLocal)
                if (off != null) airportUtcOffsetMin.putIfAbsent(from, off)
            }
            val rawTime = (stdLocal ?: std)?.substringAfter('T')?.take(5) ?: continue
            if (onlyOnDate != null) {
                val day = (stdLocal ?: std)?.substringBefore('T')?.take(10)
                    ?.replace('.', '-') ?: continue
                if (day != onlyOnDate) continue
            }
            val h = rawTime.substringBefore(':').toIntOrNull() ?: continue
            val m = rawTime.substringAfter(':').toIntOrNull() ?: continue
            if (h in 0..23 && m in 0..59) {
                val no = f.optString("designator").takeIf { it.isNotBlank() }
                // v2.36: запоминаем фактический аэропорт вылета (from) — для
                // ссылки «Купить» из нужного аэропорта Москвы (SVO/VKO/...).
                map.getOrPut("$from-$to") { ArrayList() }
                    .add(Triple(no, "%02d:%02d".format(h, m), from) to to)
            }
        }
        return map.mapValues { (_, v) -> v.sortedBy { it.first.second } }
    }

    /** Разница stdLocal - std в минутах (с поправкой на сутки). */
    private fun utcOffsetMinutes(std: String, stdLocal: String): Int? = runCatching {
        val t1 = std.substringAfter('T').split(':').let { it[0].toInt() * 60 + it[1].toInt() }
        val t2 = stdLocal.substringAfter('T').split(':').let { it[0].toInt() * 60 + it[1].toInt() }
        var diff = t2 - t1
        if (diff > 12 * 60) diff -= 24 * 60
        if (diff < -12 * 60) diff += 24 * 60
        diff
    }.getOrNull()

    /**
     * Подставляет в каждый [PriceEntry] реальное время вылета из расписания
     * (best-effort: даты дальше ~3 дней или отсутствующее направление остаются
     * без времени). Возвращает обновлённый список маршрутов.
     * v2.16: помечает depTimeVerified=true только для подтверждённых расписанием.
     * v2.17: при нескольких рейсах в дне берётся САМЫЙ РАННИЙ (раньше
     * map["from-to"] перезаписывался последним рейсом ответа — поэтому
     * «Москва→Казань 15:55» вместо утреннего DP6843 06:55).
     */
    suspend fun enrichWithDepartureTimes(routes: List<RoutePrices>): List<RoutePrices> {
        val dates = routes.flatMap { r -> r.prices.keys }.distinct()
        if (dates.isEmpty()) return routes
        // v2.47: ГЛАВНОЕ ИСПРАВЛЕНИЕ СКОРОСТИ. Начиная с v2.43 обогащение
        // расписанием делало ДВЕ волны сетевых запросов перед выдачей
        // результатов: (1) таблица вылетов на каждую дату диапазона и
        // (2) сверка цены и аэропорта Москвы ещё по 4 best-offers запроса
        // на каждую дату. Именно из-за этого загрузка стала медленнее, чем
        // в версиях без показа времени вылета.
        // v2.47: список цен отдаётся наружу СРАЗУ, без сетевых запросов здесь.
        // Если кэш расписания УЖЕ прогрет (повторный вход / pull-to-refresh) —
        // обогащаем синхронно из кэша: это бесплатно и даёт времена сразу.
        // Если не прогрет — возвращаем routes как есть; ViewModel сама
        // прогреет кэши фоном (warmUpEnrichmentCaches) и повторит вызов.
        val tables: Map<String, Map<String, List<Pair<Triple<String?, String, String?>, String>>>> =
            if (hasEnrichmentCache()) {
                dates.mapNotNull { d -> timetableCachePeek(d)?.let { d to it } }.toMap()
            } else emptyMap()
        if (tables.isEmpty()) return routes
        // v2.43: сверка цены и рейса для московских хабов — если в дне несколько
        // рейсов из разных аэропортов с разными ценами, берём аэропорт/время,
        // ЧЬЯ минимальная цена равна показанной (а не самый ранний вылет).
        // v2.47: ТОЛЬКО из кэшей (moscowPortPriceCache / prefetch), без сети:
        // нет данных — оставляем первый подтверждённый рейс как в ранних версиях.
        val portMatches = HashMap<Pair<String, String>, String?>()
        suspend fun matchedPortCached(arrivalIata: String, dateIso: String, price: Int): String? {
            val key = arrivalIata to dateIso
            if (!portMatches.containsKey(key)) {
                portMatches[key] = runCatching {
                    matchMoscowPortByPrice(arrivalIata, dateIso, price, preFetchedFromCache(dateIso))
                }.getOrNull()
            }
            return portMatches[key]
        }
        return routes.map { r ->
            val newPrices = r.prices.mapValues { (date, e) ->
                val legs: List<Pair<Triple<String?, String, String?>, String>>? = if (r.hubIata == "MOW") {
                    val mp = if (tables.isNotEmpty()) matchedPortCached(r.arrivalIata, date, e.price) else null
                    if (mp != null) tables[date]?.get("$mp-${r.arrivalIata}")
                        ?: tables[date]?.let { tbl -> firstNotNulls(tbl, r.arrivalIata) }
                    else tables[date]?.let { tbl -> firstNotNulls(tbl, r.arrivalIata) }
                } else {
                    tables[date]?.get("${r.hubIata}-${r.arrivalIata}")
                }
                // v2.36: берём самый ранний рейс, но если номер подтверждённого
                // рейса известен и летит позже — оставляем ЕГО (та же цена,
                // тот же аэропорт, что показан в карточке).
                val best = legs?.let { pickLeg(it, e.flightNo) }
                if (best != null) e.copy(
                    depTime = best.first.second,
                    depTimeVerified = true,
                    flightNo = best.first.first,
                    depPortIata = best.first.third,   // v2.36: фактический аэропорт вылета
                    arrPortIata = best.second,        // v2.37: фактический аэропорт прибытия
                ) else e
            }
            r.copy(prices = newPrices)
        }
    }

    /**
     * v2.16: обогащает объединённые направления ДО сортировки (см. fetchPrices).
     * v2.46: больше не вызывается из fetchPrices (оставлен для совместимости).
     */
    @Suppress("unused")
    private suspend fun enrichMergedWithTimetable(routes: List<RoutePrices>): List<RoutePrices> =
        enrichWithDepartureTimes(routes)

    /** Для московского хаба MOW ищем рейс из любого аэропорта Внуково/Шереметьево/... */
    private fun firstNotNulls(
        table: Map<String, List<Pair<Triple<String?, String, String?>, String>>>,
        arrivalIata: String,
    ): List<Pair<Triple<String?, String, String?>, String>>? =
        MOSCOW_AIRPORTS.firstNotNullOfOrNull { table["${it.iata}-$arrivalIata"] }

    private fun parseDay(hub: String, arr: JSONArray): List<RoutePrices> =
        parseDayFiltered(hub, arr, null)

    /**
     * v2.45: разбор ответа best-offers с фильтром по датам [keepDates] (null — все).
     * Используется пакетной загрузкой: один ответ содержит несколько дат.
     */
    private fun parseDayFiltered(
        hub: String,
        arr: JSONArray,
        keepDates: Set<String>?,
    ): List<RoutePrices> {
        val result = ArrayList<RoutePrices>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val arrival = obj.optJSONObject("arrival") ?: continue
            val minOffer = obj.optJSONObject("minOffer") ?: continue
            val price = minOffer.optInt("price", -1)
            if (price <= 0) continue
            val depDate = minOffer.optString("depDate")
            if (depDate.isBlank()) continue
            if (keepDates != null && depDate !in keepDates) continue
            val airlineRaw = minOffer.optString("airline").takeIf { it.isNotBlank() }
            val rawFlightTime = minOffer.optString("flightTime").takeIf { it.isNotBlank() }
            // v2.16: поле flightTime в best-offers — это ДЛИТЕЛЬНОСТЬ перелёта
            // («1:30» для Минск→СПб), а НЕ время вылета (реальный вылет 19:40).
            // depTime отсюда больше не подставляем: настоящее время вылёта
            // приходит только из расписания (enrichWithDepartureTimes, stdLocal).
            val entry = PriceEntry(
                depDate = depDate,
                price = price,
                airline = airlineRaw,
                flightTime = rawFlightTime,
                legsCount = airlineRaw?.split(",")?.filter { it.isNotBlank() }?.size ?: 1,
                depTime = null,
                depTimeVerified = false,
            )
            result.add(
                RoutePrices(
                    hubIata = hub,
                    arrivalIata = arrival.optString("iataCode"),
                    arrivalName = arrival.optString("name"),
                    prices = mapOf(depDate to entry),
                )
            )
        }
        return result
    }
}

/** Город/хаб вылета и его аэропорты. */
data class Hub(val iata: String, val name: String, val airports: List<Airport>)

/** Аэропорт. */
data class Airport(val iata: String, val name: String)
